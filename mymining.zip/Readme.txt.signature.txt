{
  "hash": "fdab90bd49662962051d18f3e368ae893fbcf162bd47bcdc2d975c7b291cbeb8",
  "signature": "AXkbEAABQSDZTeT8bYAn4T0DRXymM2Xrv5kTktdv7v12TXbomxgS02tMClwUr8p3Z51p2vgulBpJbKdH01z2LRufBTB7v6ji",
  "signer": "Verus Coin Foundation Releases@"
}
